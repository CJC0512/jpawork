create definer = swcamp@`%` view v_menu as
select `menudb`.`tbl_menu`.`menu_name` AS `메뉴이름`, `menudb`.`tbl_menu`.`menu_price` AS `메뉴가격`
from `menudb`.`tbl_menu`;

-- comment on column v_menu.메뉴이름 not supported: 메뉴명

-- comment on column v_menu.메뉴가격 not supported: 메뉴가격

