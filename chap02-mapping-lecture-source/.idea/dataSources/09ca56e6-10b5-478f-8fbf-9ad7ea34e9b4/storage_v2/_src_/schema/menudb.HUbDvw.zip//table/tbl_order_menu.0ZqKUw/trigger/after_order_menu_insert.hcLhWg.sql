create definer = swcamp@`%` trigger after_order_menu_insert
    after insert
    on tbl_order_menu
    for each row
BEGIN
    UPDATE tbl_order -- 이력
    SET total_order_price = total_order_price + NEW.order_amount * (SELECT menu_price FROM tbl_menu WHERE menu_code = NEW.menu_code)
	 -- NEW: 신규 insert건. 해석하자면, 신규 주문 수량과 그 메뉴 가격을 참고해 최종 주문가격를 갱신해주는 것.
    WHERE order_code = NEW.order_code;
END;

